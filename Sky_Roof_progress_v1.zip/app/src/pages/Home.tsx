import { useState } from 'react'
import '../App.css'

type Item = { name: string; price: number; image: string; note: string }

const categories = [
  { id: 'coffee', label: 'القهوة' },
  { id: 'juices', label: 'العصائر والسموزي' },
  { id: 'dessert', label: 'الحلويات' },
]

const items: Record<string, Item[]> = {
  coffee: [
    { name: 'لاتيه', price: 55, image: '/images/latte.png', note: 'إسبريسو ناعم مع حليب كريمي' },
    { name: 'كولد برو', price: 60, image: '/images/coldbrew.png', note: 'قهوة باردة بنكهة عميقة ومنعشة' },
    { name: 'إسبريسو', price: 40, image: '/images/latte.png', note: 'جرعة مركزة لعشاق القهوة' },
  ],
  juices: [
    { name: 'مانجو', price: 30, image: '/images/pastry.png', note: 'مانجو طازجة بطعم صيفي واضح' },
    { name: 'فراولة', price: 30, image: '/images/pastry.png', note: 'فراولة باردة ومنعشة' },
    { name: 'ليمون نعناع', price: 30, image: '/images/pastry.png', note: 'حمضي ومنعش مع لمسة نعناع' },
  ],
  dessert: [
    { name: 'حلويات اليوم', price: 70, image: '/images/pastry.png', note: 'اختيار يومي من الحلويات الطازجة' },
    { name: 'تشيز كيك', price: 80, image: '/images/pastry.png', note: 'قوام كريمي ولمسة حلوة متوازنة' },
  ],
}

export default function Home() {
  const [category, setCategory] = useState('coffee')
  const [index, setIndex] = useState(0)
  const current = items[category][index % items[category].length]

  const selectCategory = (id: string) => {
    setCategory(id)
    setIndex(0)
  }

  return (
    <main className="site-shell" dir="rtl">
      <header className="topbar">
        <div className="brand-mark"><span>SKY</span> ROOF</div>
        <nav>
          <a href="#home">الرئيسية</a>
          <a href="#menu">المنيو</a>
          <a href="#about">عن المكان</a>
        </nav>
        <a className="book-btn" href="#menu">شوف المنيو <span>↗</span></a>
      </header>

      <section className="hero" id="home">
        <div className="hero-copy">
          <div className="eyebrow">CAFE · ROOFTOP · NAG HAMMADI</div>
          <h1>مزاج جديد.<br /><em>كل يوم.</em></h1>
          <p>قهوة معمولة على مزاجك، مشروبات منعشة وحلويات تخلي القعدة ليها طعم تاني.</p>
          <div className="hero-actions">
            <a className="primary-btn" href="#menu">استكشف المنيو <span>→</span></a>
            <span className="hero-note">قهوة • صحاب • روف</span>
          </div>
        </div>
        <div className="hero-visual">
          <div className="hero-glow" />
          <img src="/images/latte.png" alt="Sky Roof latte" />
          <div className="hero-stamp">SKY<br />ROOF<br /><small>CAFE</small></div>
        </div>
      </section>

      <section className="menu-section" id="menu">
        <div className="section-heading">
          <div>
            <span className="eyebrow">OUR MENU</span>
            <h2>اختار مزاجك.</h2>
          </div>
          <span className="section-count">01 / 03</span>
        </div>

        <div className="category-row">
          {categories.map((cat, i) => (
            <button key={cat.id} className={category === cat.id ? 'active' : ''} onClick={() => selectCategory(cat.id)}>
              <span>0{i + 1}</span>{cat.label}
            </button>
          ))}
        </div>

        <div className="menu-stage" key={`${category}-${index}`}>
          <div className="menu-photo">
            <div className="photo-number">0{index + 1}</div>
            <img src={current.image} alt={current.name} />
          </div>
          <div className="menu-info">
            <span className="item-kicker">SIGNATURE SELECTION</span>
            <h3>{current.name}</h3>
            <p>{current.note}</p>
            <div className="price-row"><strong>{current.price}</strong><span>جنيه</span></div>
            <div className="item-nav">
              <button onClick={() => setIndex((index - 1 + items[category].length) % items[category].length)}>←</button>
              <div className="dots">{items[category].map((_, i) => <span key={i} className={i === index % items[category].length ? 'on' : ''} />)}</div>
              <button onClick={() => setIndex((index + 1) % items[category].length)}>→</button>
            </div>
          </div>
        </div>
      </section>

      <section className="about" id="about">
        <span className="eyebrow">THE SKY ROOF MOOD</span>
        <h2>قعدة فوق،<br /><em>ومود أحلى.</em></h2>
        <p>مكان بسيط في شكله، كبير في تفاصيله. تعالى للقهوة، اقعد مع صحابك، وسيب الباقي علينا.</p>
      </section>

      <footer><span>SKY ROOF CAFE</span><span>© 2026</span></footer>
    </main>
  )
}
